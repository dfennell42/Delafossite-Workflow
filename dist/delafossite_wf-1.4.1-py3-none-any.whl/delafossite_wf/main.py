#import modules
import typer
from typing_extensions import Annotated
import os
import sys
import shutil
from dotenv import load_dotenv
#import from files
from . import version
#bash script run-all
from .modifystructure import modify_structure
from .MagMom_recursive import process_poscar_files
from .POTCAR_cat import process_directories
from .VASP_input import generate_vasp_inputs_in_dir
from .modINCAR import update_incar_files_with_magmom
#modify ignoring symmetry
from .modify_ignore_sym import modify_without_sym
#bash script run-removal
from .remove_pairs import process_vasp_inputs
from .removed_pairs_INCARmod import process_pairs_mod_dirs
#remove single atoms
from .remove_atoms import process_vasp_inputs_nosym
#add pairs
from .add_pairs import process_vasp_dirs
#add single atoms
from .add_atoms import process_vasp_dirs_nosym
#bash script process data
from .get_e_pristine import get_all_e
from .Calc_Evac import process_e_vac
from .calc_Eads import process_e_ads
#bash script run pdos
from .createPDOS import process_vasp_inputs as pdos_vasp_inputs
from .pdos_INCARmod import process_pdos_dirs
#bash script process pdos
from .vasp_pdos import process_pdos_dirs as parse_pdos_dirs
from .integrate_pdos import integrate_all_pdos
from .tot_int import get_all_data
#plot pdos
from .PDOS_plotter import plot_pdos
#initialize
from .initialize import init_settings
#error check
from .err_check import err_fix
#update
from .wf_update import check_vrsn
#band structures & bandgap
from .bands_input import create_all_bands
from .get_bandgap import get_band_data
#create app
app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})

#create callback for version
@app.callback(invoke_without_command=True)
def vrsn_callback(
        ctx: typer.Context,
        vrsn: Annotated[bool, typer.Option("--version", '-v')] = False
         ):
    if ctx.invoked_subcommand is None and vrsn == True:
        print(f'Delafossite workflow version is {version}')
    
#create commands
@app.command()
def init():
    '''Initializes workflow settings.'''
    init_settings()

@app.command()
def modify(
        no_sym: Annotated[bool, typer.Option("--ignore-symmetry",'-i',help='Ignores symmetry, modifying individual atoms rather than pairs. If using this option, need ModsIdx.txt.')] = False
        ):
    '''Modifies delafossite structure based on user input. Needs Mods.txt or ModsIdx.txt if using --ignore-symmetry/-i. '''
    load_dotenv()
    if no_sym == False:
        modify_structure(os.getcwd())
    elif no_sym == True:
        modify_without_sym(os.getcwd())
    process_poscar_files(mod=None, ignore_sym=no_sym)
    process_directories(os.getenv('POT_PATH'), vac = False, add = False)
    generate_vasp_inputs_in_dir(os.getcwd())
    update_incar_files_with_magmom(os.getcwd(),ignore_sym=no_sym)

@app.command()
def removepairs():
    '''Removes atom pairs from structures '''
    load_dotenv()
    element_name = process_vasp_inputs(os.getcwd())
    process_pairs_mod_dirs(os.getcwd(),element_name,'Removed',ignore_sym=False)
    process_directories(os.getenv('POT_PATH'), vac = True, add = False)

@app.command()
def addpairs():
    '''Adds pairs of atoms to structures.'''
    load_dotenv()
    element_name = process_vasp_dirs(os.getcwd())
    process_pairs_mod_dirs(os.getcwd(), element_name, 'Added', ignore_sym=False)
    process_directories(os.getenv('POT_PATH'), vac=False, add=True)

@app.command()
def removeatoms():
    '''Removes SINGLE atoms, ignoring symmetry. NOTE: Ignoring symmetry greatly increases calculation time.'''
    load_dotenv()
    element_name = process_vasp_inputs_nosym(os.getcwd())
    process_pairs_mod_dirs(os.getcwd(), element_name, 'Removed',ignore_sym= True)
    process_directories(os.getenv('POT_PATH'), vac = True, add = False)

@app.command()
def addatoms():
    '''Adds SINGLE atoms to structures, ignoring symmetry. NOTE: Ignoring symmetry greatly increases calculation time.'''
    load_dotenv()
    element_name = process_vasp_dirs_nosym(os.getcwd())
    process_pairs_mod_dirs(os.getcwd(), element_name, 'Added',ignore_sym=True)
    process_directories(os.getenv('POT_PATH'), vac=False, add=True)
    
@app.command()
def gete():
    '''Gets pristine E, E_vac, and E_ads.'''
    get_all_e(os.getcwd())
    process_e_vac(os.getcwd())
    process_e_ads(os.getcwd())
    
@app.command()
def pdos():
    '''sets up PDOS calculations'''
    pdos_vasp_inputs(os.getcwd())
    process_pdos_dirs(os.getcwd())
    
@app.command()
def parse():
    '''Parses PDOS data into individual files and integrates '''
    parse_pdos_dirs(os.getcwd())
    integrate_all_pdos(os.getcwd())
    get_all_data(os.getcwd())
    
@app.command()
def integrate():
    '''Integrates the PDOS files. Note: Files must be parsed before integration. The parse command parses AND integrates, so this command is only if integration needs to be performed on already parsed files. '''
    integrate_all_pdos(os.getcwd())
    get_all_data(os.getcwd())
    
@app.command()
def plot(
        no_show:Annotated[bool,typer.Option('--no-show-image','-n',help='Do not display plot in X11 window after running command.',show_default=False)] ,
    ):
    '''Plots PDOS'''
    plot_pdos(os.getcwd(),no_show)

@app.command()
def bands(k: Annotated[str, typer.Option('--kpoints', '-k', help = 'The number of K points to use per line in KPOINTS_OPT file. Default is 10.')] = '10',
        ):
    '''Sets up band structure calculations using hybrid functionals. Note: Requires WAVECAR file from completed DFT structural optimization.'''
    create_all_bands(os.getcwd(),k)

@app.command()
def getgap():
    '''Gets band gap, Fermi energy, VBM, and CBM for each modification directory and outputs data into a CSV file.'''
    get_band_data(os.getcwd())

@app.command()
def submit(
        calc: Annotated[str, typer.Argument(help='The type of calculation to submit. Options: struc: Pristine or vacancy surface calculations. pdos: PDOS calculations. bands: Band structure calculations.')] = 'struc',
        vac:Annotated[bool,typer.Option("--vac","-v",help='Run only vacancy calculations. Does not work with calc = pdos')] = False,
        add: Annotated[bool,typer.Option("--add","-a",help='Run only adsorption calculations. Does not work with calc = pdos')] = False,
        ):
    '''Submits vasp calculations.'''
    pkgdir = sys.modules['delafossite_wf'].__path__[0]
    filedir = os.path.expanduser('~/wf-user-files')
    fullpath = os.path.join(filedir, 'vasp.sh')
    shutil.copy(fullpath, os.getcwd())
    fpath = os.path.join(pkgdir,'submitall-vasp.sh')
    if calc.lower() == 'struc':
        if vac:
            calc_type = "*_Removed"
        elif add:
            calc_type = "*_Added"
        else:
            calc_type = "all"
    elif calc.lower() == 'pdos':
        calc_type = "PDOS"
    elif calc.lower() == 'bands':
        calc_type = "Band_struc"
    os.system(f'bash {fpath} {calc_type}')
        
@app.command()
def check(
        no_submit:Annotated[bool,typer.Option("--no-submit","-n",help='Use -n or --no-submit to run check without autosubmitting calculations')] = False
        ):
    '''Checks vasp.out for errors and fixes and resubmits calculations if possible.'''
    err_fix(os.getcwd(),no_submit)

@app.command()
def update(
        editable:Annotated[bool,typer.Option("--editable",'-e',help='Install the workflow as an editable package.')] = False,
):
    '''Checks workflow version and updates if necessary.'''
    if editable == True:
        suffix = '.tar.gz'
    elif editable == False:
        suffix = '.whl'
    check_vrsn(suffix)
